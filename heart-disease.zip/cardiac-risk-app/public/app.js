const form = document.getElementById('patient-form');
const errorEl = document.getElementById('form-error');
const emptyEl = document.getElementById('result-empty');
const bodyEl = document.getElementById('result-body');
const gaugeFill = document.getElementById('gauge-fill');
const riskPercentEl = document.getElementById('risk-percent');
const riskLabelEl = document.getElementById('risk-label');
const submitBtn = form.querySelector('.submit-btn');

const GAUGE_LENGTH = 188.5; // matches stroke-dasharray in style.css

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  errorEl.hidden = true;

  const data = Object.fromEntries(new FormData(form).entries());
  const payload = {
    age: Number(data.age),
    sex: data.sex,
    chestPainType: data.chestPainType,
    restingBP: Number(data.restingBP),
    cholesterol: Number(data.cholesterol),
    fastingBS: Number(data.fastingBS),
    restingECG: data.restingECG,
    maxHR: Number(data.maxHR),
    exerciseAngina: data.exerciseAngina,
    oldpeak: Number(data.oldpeak),
    stSlope: data.stSlope,
  };

  submitBtn.disabled = true;
  submitBtn.textContent = 'Estimating…';

  try {
    const res = await fetch('/api/predict', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || 'The model could not score these values.');
    }

    const result = await res.json();
    renderResult(result);
  } catch (err) {
    errorEl.textContent = err.message || 'Something went wrong. Please try again.';
    errorEl.hidden = false;
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Estimate risk';
  }
});

function renderResult(result) {
  emptyEl.hidden = true;
  bodyEl.hidden = false;

  const offset = GAUGE_LENGTH * (1 - result.probability);
  gaugeFill.style.strokeDashoffset = String(offset);

  const isHigh = result.prediction === 1;
  gaugeFill.style.stroke = isHigh ? 'var(--brick)' : 'var(--sage)';

  riskPercentEl.textContent = `${result.risk_percent}%`;
  riskLabelEl.textContent = result.label;
  riskLabelEl.className = 'risk-label ' + (isHigh ? 'high' : 'low');
}
